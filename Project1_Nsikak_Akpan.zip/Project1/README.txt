"s3 bucket url": http://my-656379065975-bucket.s3-website-us-east-1.amazonaws.com

"CloudFront domain name url": https://d1ws1jquexurnv.cloudfront.net

"object url" : https://my-656379065975-bucket.s3.amazonaws.com/index.html